classdef digraphSubclass < digraph
%DIGRAPHSUBCLASS Subclass used only for testing.

% Copyright 2014 The MathWorks, Inc.

% No content: leave everything to the superclass

end